<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Canal extends Model
{
    protected $fillable = [
        "nomCanal"
    ];

 public function programas(){
    return $this->hasMany('App\Programa');
 }
}
