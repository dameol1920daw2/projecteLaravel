<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Programa extends Model
{
    protected $fillable = [
      "nomPrograma",
      "descripcioPrograma",
      "tipusPrograma",
      "classificacioPrograma",
      "idCanal"
  ];
    public function canal(){
        return $this->belongsTo('App\Canal');
     }

     public function graellas(){
        return $this->belongsToMany('App\Graella');
     }
}
