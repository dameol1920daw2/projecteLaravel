@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Dashboard</div>

                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif
					<a href="{{route('canalCreate')}}"> <button type="button">Crear canal</button></a>
                    <a href="{{route('programaCreate')}}"> <button type="button">Crear programa</button></a>
                    <a href="{{route('graellaCreate')}}"> <button type="button">Crear graella</button></a>
                    <a href="{{route('graellaIndex')}}"><button type="button">Veure graella</button></a>
                    <a href="{{route('editCanal')}}"><button type="button">Editar canal</button></a>
                    
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
