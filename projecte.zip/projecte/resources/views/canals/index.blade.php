<div>
	<p>Canal Creat/Actualitzat</p>
	<a href="{{route('home')}}"><button type="button">Home</button></a>
</div>
