<form method="GET" action="{{route('canalStore')}}">

  <label >Nom canal</label>
  <input type="text" name="nomCanalR" ></input>

  <button type="submit" >Crear canal</button>
  <a href="{{route('home')}}"><button type="button" >Home</button></a>

</form>
