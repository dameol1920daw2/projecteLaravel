<h2>Editar un canal</h3>

@if(count($errors) > 0)
	<div>
		<ul>
			@foreach($errors->all() as $error)
			<li>{{$error}}</li>
			@endforeach
		</ul>
	</div>
@endif
<form method="get" action="{{action('CanalController@update')}}">
	{{csrf_field()}}
	<label >Nom Canal a editar</label>
	<select name="id"> 
		@foreach($editCanal as $idCanal)
			<option value="{{$idCanal-> id}}">{{$idCanal-> nomCanal}}</option>
		@endforeach
	</select>
	<label >Nom canal</label>
	<input type="text"  name="nomCanal" placeholder="Escribe el nombre..." /><br><br>

	<button type="submit">Editar canal</button>

</form>


<a href="{{route('home')}}"><button type="button">Home</button></a>
