
<table>
                        <thead>
                        
                            <tr>
                                <th>Id</th>
                                <th>Canal</th>
                                <th>Programa</td>
                                <th>Dia</th>
                                <th>Hora</th>

                            </tr>
                        </thead>
                        <tbody>
                        @foreach($graellas as $graella)
                        <tr>
                        <th>    {{$graella -> id}}</th>
                        <th>@foreach($graella->programas as $programa) 
                        @foreach ($canals as $canal)
                             @if($programa->idCanal == $canal->id)
                                {{$canal->nomCanal}}
                              @endif
                        @endforeach
                        @endforeach
                        </th>
                        <th>
                        @foreach($graella->programas as $programa) 
                            {{$programa->nomPrograma}}
                    @endforeach
                        </th>
                        <th> {{$graella -> diaEmision}}</th>
                        <th> {{$graella -> horaEmision}}</th>
                        </tr>
                        @endforeach
                        </tbody>
</table>
<a href="{{route('home')}}"><button type="button">Home</button></a>
