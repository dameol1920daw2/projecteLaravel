<form method="GET" action="{{route('graellaStore')}}">

<label >Hora de l'emissió</label>
<input type="time" name="horaEmisionR"></input>
<label >Dia de l'emissió</label>
<input type="date" name="diaEmisionR"></input>

<label >Nom del programa</label>
<select name="idPrograma"> 
    @foreach($idPrograma as $programa)
              <option value="{{$programa-> id}}">    {{$programa-> nomPrograma}}  </option>  
    @endforeach
</select>

</div>
<button type="submit">Crear graella</button>
<a href="{{route('home')}}"><button type="button">Home</button></a>


</form>
