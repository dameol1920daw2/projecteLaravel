<form method="GET" action="{{route('programaStore')}}">


<label >Nom programa</label>
<input type="text"  name="nomProgramaR"></input>
<label >Descripcio programa</label>
<input type="text"  name="descripcioProgramaR"></input>
<label >Tipus programa</label>
<input type="text"  name="tipusProgramaR"></input>
<label >Classificacio programa</label>
<input type="text"  name="classificacioProgramaR"></input>
<label >Id canal</label>
<select name="idCanalR"> 
    @foreach($canales as $canal)
              <option value = "{{$canal-> id}}" >    {{$canal-> nomCanal}}  </option>  
    @endforeach
</select>
<button type="submit">Crear programa</button>
<a href="{{route('home')}}"><button type="button">Home</button></a>

</form>
