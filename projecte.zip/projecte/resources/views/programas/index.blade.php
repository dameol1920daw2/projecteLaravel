<div>
	<p>Programa Creat</p>
	<a href="{{route('home')}}"><button type="button">Home</button></a>
</div>
