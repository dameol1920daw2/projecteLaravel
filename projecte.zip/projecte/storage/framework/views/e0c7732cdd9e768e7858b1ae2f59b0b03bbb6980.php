
<table>
                        <thead>
                        
                            <tr>
                                <th>Id</th>
                                <th>Canal</th>
                                <th>Programa</td>
                                <th>Dia</th>
                                <th>Hora</th>

                            </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $graellas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $graella): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                        <th>    <?php echo e($graella -> id); ?></th>
                        <th><?php $__currentLoopData = $graella->programas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $programa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                        <?php $__currentLoopData = $canals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $canal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             <?php if($programa->idCanal == $canal->id): ?>
                                <?php echo e($canal->nomCanal); ?>

                              <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </th>
                        <th>
                        <?php $__currentLoopData = $graella->programas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $programa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                            <?php echo e($programa->nomPrograma); ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </th>
                        <th> <?php echo e($graella -> diaEmision); ?></th>
                        <th> <?php echo e($graella -> horaEmision); ?></th>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
</table>
<a href="<?php echo e(route('home')); ?>"><button type="button">Home</button></a>
<?php /**PATH /home/dameol/Documentos/projecte/resources/views/graellas/index.blade.php ENDPATH**/ ?>