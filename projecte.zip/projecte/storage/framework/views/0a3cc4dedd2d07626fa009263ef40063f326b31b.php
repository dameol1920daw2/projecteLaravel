<div>
	<p>Canal Creat/Actualitzat</p>
	<a href="<?php echo e(route('home')); ?>"><button type="button">Home</button></a>
</div>
<?php /**PATH /home/dameol/Documentos/projecte/resources/views/canals/index.blade.php ENDPATH**/ ?>