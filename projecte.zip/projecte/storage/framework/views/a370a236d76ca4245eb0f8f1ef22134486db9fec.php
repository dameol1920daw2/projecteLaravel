<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Dashboard</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
					<a href="<?php echo e(route('canalCreate')); ?>"> <button type="button">Crear canal</button></a>
                    <a href="<?php echo e(route('programaCreate')); ?>"> <button type="button">Crear programa</button></a>
                    <a href="<?php echo e(route('graellaCreate')); ?>"> <button type="button">Crear graella</button></a>
                    <a href="<?php echo e(route('graellaIndex')); ?>"><button type="button">Veure graella</button></a>
                    <a href="<?php echo e(route('editCanal')); ?>"><button type="button">Editar canal</button></a>
                    
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dameol/Documentos/projecte/resources/views/home.blade.php ENDPATH**/ ?>