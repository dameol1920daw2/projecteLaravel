<form method="GET" action="<?php echo e(route('programaStore')); ?>">


<label >Nom programa</label>
<input type="text"  name="nomProgramaR"></input>
<label >Descripcio programa</label>
<input type="text"  name="descripcioProgramaR"></input>
<label >Tipus programa</label>
<input type="text"  name="tipusProgramaR"></input>
<label >Classificacio programa</label>
<input type="text"  name="classificacioProgramaR"></input>
<label >Id canal</label>
<select name="idCanalR"> 
    <?php $__currentLoopData = $canales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $canal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value = "<?php echo e($canal-> id); ?>" >    <?php echo e($canal-> nomCanal); ?>  </option>  
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>
<button type="submit">Crear programa</button>
<a href="<?php echo e(route('home')); ?>"><button type="button">Home</button></a>

</form>
<?php /**PATH /home/dameol/Documentos/projecte/resources/views/programas/create.blade.php ENDPATH**/ ?>