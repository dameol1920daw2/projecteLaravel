<form method="GET" action="<?php echo e(route('canalStore')); ?>">

  <label >Nom canal</label>
  <input type="text" name="nomCanalR" ></input>

  <button type="submit" >Crear canal</button>
  <a href="<?php echo e(route('home')); ?>"><button type="button" >Home</button></a>

</form>
<?php /**PATH /home/dameol/Documentos/projecte/resources/views/canals/create.blade.php ENDPATH**/ ?>