<h2>Editar un canal</h3>

<?php if(count($errors) > 0): ?>
	<div>
		<ul>
			<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<li><?php echo e($error); ?></li>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</ul>
	</div>
<?php endif; ?>
<form method="get" action="<?php echo e(action('CanalController@update')); ?>">
	<?php echo e(csrf_field()); ?>

	<label >Nom Canal a editar</label>
	<select name="id"> 
		<?php $__currentLoopData = $editCanal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $idCanal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<option value="<?php echo e($idCanal-> id); ?>"><?php echo e($idCanal-> nomCanal); ?></option>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</select>
	<label >Nom canal</label>
	<input type="text"  name="nomCanal" placeholder="Escribe el nombre..." /><br><br>

	<button type="submit">Editar canal</button>

</form>


<a href="<?php echo e(route('home')); ?>"><button type="button">Home</button></a>
<?php /**PATH /home/dameol/Documentos/projecte/resources/views/canals/edit.blade.php ENDPATH**/ ?>