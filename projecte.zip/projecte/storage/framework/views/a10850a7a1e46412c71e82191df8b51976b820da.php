<form method="GET" action="<?php echo e(route('graellaStore')); ?>">

<label >Hora de l'emissió</label>
<input type="time" name="horaEmisionR"></input>
<label >Dia de l'emissió</label>
<input type="date" name="diaEmisionR"></input>

<label >Nom del programa</label>
<select name="idPrograma"> 
    <?php $__currentLoopData = $idPrograma; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $programa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($programa-> id); ?>">    <?php echo e($programa-> nomPrograma); ?>  </option>  
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>

</div>
<button type="submit">Crear graella</button>
<a href="<?php echo e(route('home')); ?>"><button type="button">Home</button></a>


</form>
<?php /**PATH /home/dameol/Documentos/projecte/resources/views/graellas/create.blade.php ENDPATH**/ ?>